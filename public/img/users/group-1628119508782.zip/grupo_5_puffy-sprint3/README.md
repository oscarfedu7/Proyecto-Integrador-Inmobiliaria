# Puffy

## Trello
https://trello.com/b/GdfpiR3V/puffy-proyecto-integrador

## Integrantes:
- Gabriel Espinosa Burguete
- Pedro Esteban Sevilla Gutiérrez
- Montserrat Elizabeth Olmedo Mancilla

### Supervisor:
- Francisco Rafael Arce García

## Descripción

### Temática
E-commerce para repostería, donde los reposteros (caseros o negocios) pueden vender sus postres. Los postres incluyen pasteles, galletas, gelatinas, flan, cupcakes, etc.

### Público Objetivo
- Reposteros amateur
- Reposteros profesionales
- Personas interesadas en postres

### Descripción de los integrantes
- Gabo: soy de ingeniería en computación, llevo un tiempo interesado en desarrollo web. Me gusta la literatura (novelas y cuentos) 📖, jugar videojuegos con mis amigos 🎮 y colorear 🖍. Tengo conocimientos en varios lenguajes de programación y otras tecnologías como git, docker, base de datos relacionales y computo en la nube. Estudie la especialización en IA o(\*￣▽￣\*)ブ, pero nunca me logró gustar tanto como el desarrollo web.
- Montse:¡Hola! Soy Montse, egresada de la carrera de Actuaría.  Me considero una persona tranquil1a, con muchas ganas de aprender "de todo un poco" (Desarrollo Web, es un ejemplo). Me encanta viajar, indagar en información relacionada al arte y la cultura. Tengo conocimiento de lenguajes de programación como R y Python aplicado a la estadística y actualmente, busco complementarlo con Desarrollo Web, de forma que pueda crear productos relacionados a mis intereses profesionales, como lo son las finanzas corporativas, bursátiles y tecnológicas (Fintech).
- Esteban: Muy buen día. Soy un estudiante de la carrera de ingeniería en informática. Actualmente, trabajo como becario de desarrollo en una empresa especializada en el software gubernamental. Me gusta mi carrera lo que me ha permitido dedicarle horas extras de mi tiempo libre por puro entretenimiento.
Disfruto del sentimiento que existe cuando resuelves un problema que tiene tiempo torturandote (obviamente, me refiero a problemas de programación). 
También, aquel sentimiento que se da cuando le enseñas a alguien más lo que has hecho, y se queda pasmado.

## Inspiración:
### [Canasta Rosa](https://canastarosa.com/)
Nuestra mayor inspiración, se puede resumir como un mercado libre de artesanías y comida.

### [Wizeline](https://www.wizeline.com/)
Nos gustaron las animaciones de la landing page.

### [Mercado Libre](https://articulo.mercadolibre.com.mx/)
En la búsqueda los productos se ordenan en una cuadrícula dispareja que le da su propio carácter a cada producto. También, la sección de preguntas de cada producto que te deja hacerlas al vendedor directamente, se da una interacción entre el usuario y el vendedor.

### [H&M](https://www2.hm.com/es_mx/)
Tiene un wishlist bien integrado, donde te permite agregar un producto a ésta (sin agregarlo al carrito) y la puedes consultar fácilmente. Su scroll que usa un botón de "Ver más", en lugar de scroll infinito o páginas.

### [Amazon](https://www.amazon.com.mx/)
Nos gusta el fácil acceso de Amazon, con su barra de búsqueda siempre visible que permite hacer consultas en cualquier momento. Además, Amazon siempre personaliza la página de inicio según tus búsquedas y compras previas. Puedes consultar otros productos del mismo vendedor.
