# Sprint 3 - Weekly standups
### Se realizan los miércoles y domingos.
**Instrucciones:** Un resumen de las tareas completadas, los impedimentos encontrados y las soluciones propuestas indicando los integrantes.

## (1) Domingo 20/06/2021
