# Sprint 1 - Retroalimentación

## Montserrat
1. Comenzar a hacer: reforzar conocimientos en HTML y CSS con videos y práctica.
2. Continuar haciendo: tener los tiempos organizados y ver con anticipación las clases en playgroud.
3. Dejar de hacer: dedicar poco tiempo al material que se presenta a lo largo del curso.

## Esteban
1. Comenzar a hacer: prepararme antes de las reuniones.
2. Continuar haciendo: avanzar el sprint en mi tiempo libre.
3. Dejar de hacer: participar poco en las reuniones.

## Gabriel
1. Comenzar a hacer: repartir el trabajo en la semana.
2. Continuar haciendo: organizar las cargas de trabajo.
3. Dejar de hacer: hablar tanto en las reuniones, no hacerlo todo en una tarde..

## Equipo
1. Comenzar a hacer: estar más en contacto a lo largo de la semana.
2. Continuar haciendo: reuniones programadas y seguir abiertos a ideas y opiniones distintas.
3. Dejar de hacer: no perder el tiempo en cosas pequeñas.

# Sprint 2 - Retroalimentación

## Montserrat
1. Comenzar a hacer: Investigar más acerca del tema de Templates, que será parte de la entrega en este tercer sprint.
3. Continuar haciendo: Ver más videos de Github y Git para comprender mejor cómo funciona y poder hacer entregas más fácilmente. 
4. Dejar de hacer: Participar poco en Trello.

## Esteban
1. Comenzar a hacer: Empezar a trabajar el sprint desde el primer día.
2. Continuar haciendo: Utilizar atributos y funciones extras que aprendí de CSS en otros cursos.
3. Dejar de hacer: Dejar todo para último.

## Equipo
1. Comenzar a hacer: 
2. Continuar haciendo: 
3. Dejar de hacer: 
